package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class SecondActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManagert;
    private boolean isColort = false;
    private View viewt;
    private long lastUpdatet;
    Button startbtnt, stopbtnt, nextbtnt;
    GraphView graphViewt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        startbtnt = (Button) findViewById(R.id.btnstarttwo);
        stopbtnt = (Button) findViewById(R.id.btnstoptwo);
        graphViewt = (GraphView) findViewById(R.id.graphtwo);
        nextbtnt = (Button) findViewById(R.id.btnnexttwo);

        startbtnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onResume();
            }
        });

        stopbtnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPause();
            }
        });

        nextbtnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });
        viewt = findViewById(R.id.textviewtwo);
        viewt.setBackgroundColor(Color.GREEN);


        sensorManagert = (SensorManager) getSystemService(SENSOR_SERVICE);
        lastUpdatet = System.currentTimeMillis();
    }

    public void openNewActivity()
    {
        Intent intent = new Intent(this,thirdActivity.class);
        startActivity(intent);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            getAccelerometer(event);
        }
    }
    private void getAccelerometer(SensorEvent event) {
        float[] values = event.values;
        // Movement
        float x = values[0];
        float y = values[1];
        float z = values[2];

        float accelationSquareRoot = (x * x + y * y + z * z)
                / (SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);

        long actualTime = System.currentTimeMillis();
        Toast.makeText(getApplicationContext(),String.valueOf(accelationSquareRoot)+" "+
                SensorManager.GRAVITY_EARTH,Toast.LENGTH_SHORT).show();

        try {
            LineGraphSeries<DataPoint> series = new LineGraphSeries < > (new DataPoint[] {
                    new DataPoint(0, 1),
                    new DataPoint(Float.valueOf(x), Float.valueOf(y))
            });
            graphViewt.addSeries(series);
        } catch (IllegalArgumentException e) {
            Toast.makeText(SecondActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }

        if (accelationSquareRoot >= 2) //it will be executed if you shuffle
        {

            if (actualTime - lastUpdatet < 200) {
                return;
            }
            lastUpdatet = actualTime;//updating lastUpdate for next shuffle
            if (isColort) {
                viewt.setBackgroundColor(Color.GREEN);

            } else {
                viewt.setBackgroundColor(Color.RED);
            }
            isColort = !isColort;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // register this class as a listener for the orientation and
        // accelerometer sensors
        sensorManagert.registerListener(this,sensorManagert.getDefaultSensor(Sensor.TYPE_GYROSCOPE),
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        // unregister listener
        super.onPause();
        sensorManagert.unregisterListener(this);
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
