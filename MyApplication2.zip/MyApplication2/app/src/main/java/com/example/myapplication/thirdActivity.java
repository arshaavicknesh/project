package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class thirdActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManagerth;
    private boolean isColorth = false;
    private View viewth;
    private long lastUpdateth;
    Button startbtnth, stopbtnth, nextbtnth;
    GraphView graphViewth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        startbtnth = (Button) findViewById(R.id.btnstartthree);
        stopbtnth = (Button) findViewById(R.id.btnstopthree);
        graphViewth = (GraphView) findViewById(R.id.graphthree);
        nextbtnth = (Button) findViewById(R.id.btnnextthree);


        startbtnth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onResume();
            }
        });

        stopbtnth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPause();
            }
        });

        nextbtnth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opennewactivity();
            }
        });

        viewth = findViewById(R.id.textviewthree);
        viewth.setBackgroundColor(Color.GREEN);


        sensorManagerth = (SensorManager) getSystemService(SENSOR_SERVICE);
        lastUpdateth = System.currentTimeMillis();
    }

    public void opennewactivity()
    {
        Intent intent = new Intent(this,fourthActivity.class);
        startActivity(intent);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_LIGHT) {
            getAccelerometer(event);
        }
    }

    private void getAccelerometer(SensorEvent event) {
        float[] values = event.values;
        // Movement
        float x = values[0];

        try {
            LineGraphSeries<DataPoint> series = new LineGraphSeries < > (new DataPoint[] {
                    new DataPoint(0, 1),
                    new DataPoint(Float.valueOf(0), Float.valueOf(x))
            });
            graphViewth.addSeries(series);
        } catch (IllegalArgumentException e) {
            Toast.makeText(thirdActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // register this class as a listener for the orientation and
        // accelerometer sensors
        sensorManagerth.registerListener(this,sensorManagerth.getDefaultSensor(Sensor.TYPE_LIGHT),
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        // unregister listener
        super.onPause();
        sensorManagerth.unregisterListener(this);
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
