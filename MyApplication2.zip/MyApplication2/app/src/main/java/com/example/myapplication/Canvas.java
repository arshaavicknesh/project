package com.example.myapplication;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.widget.TextView;

public class Canvas extends View {
    Paint paint = new Paint();
    public Canvas(Context context) {
        super(context);
        paint.setColor(Color.BLACK);
    }

    @Override
    protected void onDraw(android.graphics.Canvas canvas) {
        canvas.drawLine(50,100, 80, 600, paint);
    }
}
